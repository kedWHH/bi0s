#include <stdio.h>

void main(){
	int a=25,b=32;
	int i,s=0;
	for(i=1;i<=b;i++){
		s = s + a;
	}
	printf("Hence 25 * 32 = %d", s);
}
